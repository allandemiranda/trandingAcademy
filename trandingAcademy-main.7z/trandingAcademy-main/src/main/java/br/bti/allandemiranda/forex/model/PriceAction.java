//package br.bti.allandemiranda.forex.model;
//
///**
// * The enum Price action.
// */
//public enum PriceAction {
//  LOW,
//  HIGH,
//  NEUTRAL
//}
