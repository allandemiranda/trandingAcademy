package br.bti.allandemiranda.forex.model;

/**
 * The enum Position.
 */
public enum Position {
  BUY,
  SELL
}
