package br.bti.allandemiranda.forex.model;

/**
 * The enum Currency.
 */
public enum Currency {
  EUR,
  USD,
  JPY,
  GBP,
  AUD,
  CAD,
  CHF,
  NZD
}
