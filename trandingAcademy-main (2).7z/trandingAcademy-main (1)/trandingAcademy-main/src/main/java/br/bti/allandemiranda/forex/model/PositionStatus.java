//package br.bti.allandemiranda.forex.model;
//
///**
// * The enum Position status.
// */
//public enum PositionStatus {
//  OPEN,
//  ClOSE_MANUALLY,
//  ClOSE_MARGIN_LOSS,
//  ClOSE_STOP_LOSS,
//  ClOSE_TAKE_PROFIT
//}
