package br.bti.allandemiranda.forex.model;

import java.util.InputMismatchException;

public class CurrencyPair {
  private Currency base;
  private Currency profit;

  public CurrencyPair(Currency base, Currency profit) {
    setBase(base);
    setProfit(profit);
  }

  public CurrencyPair(String base, String profit) {
    setBase(base);
    setProfit(profit);
  }

  public Currency getBase() {
    return base;
  }

  private void setBase(Currency base) {
    if(base.equals(getProfit())){
      throw new InputMismatchException("Base Currency can't be equal Profit Currency");
    } else {
      this.base = base;
    }
  }

  private void setBase(String base) {
    setBase(Currency.valueOf(base));
  }

  public Currency getProfit() {
    return profit;
  }

  private void setProfit(Currency profit) {
    if(profit.equals(getBase())){
      throw new InputMismatchException("Profit Currency can't be equal Base Currency");
    } else {
      this.profit = profit;
    }
  }

  private void setProfit(String profit) {
    setProfit(Currency.valueOf(profit));
  }
}
