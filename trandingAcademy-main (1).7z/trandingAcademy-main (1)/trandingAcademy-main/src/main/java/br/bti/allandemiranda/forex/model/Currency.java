package br.bti.allandemiranda.forex.model;

/**
 * The enum Currency.
 */
public enum Currency {
  EUR,
  USD,
  GBP,
  AUD,
  NZD
}
